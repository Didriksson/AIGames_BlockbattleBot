package field;

public class Row {

    private Cell[] cells;
    
    public Row(Cell[] cells) {
	this.cells = cells;
    }
    
    public int getNumberOfIsolatedCells(){
	int iso = 0;
	for(int i = 0 ; i < cells.length ; i ++)
	{
	    
	}
	return iso;
	
	
    }
    

}
