package moves;

import java.util.ArrayList;

public class Move {
    public ArrayList<MoveType> moves;
    public int score;
   
}
